**Overview**
- Purpose: Static footer.

**Findings**
- None.

**Security & Reliability**
- N/A.

**Performance & Complexity**
- O(1).

**Readability & Maintainability**
- Consider pulling year dynamically.

**Quick Fixes**
- Use `{new Date().getFullYear()}`.

**Test Ideas**
- Snapshot.

