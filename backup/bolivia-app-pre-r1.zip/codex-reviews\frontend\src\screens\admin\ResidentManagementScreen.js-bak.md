**Overview**
- Purpose: Legacy/backup of ResidentManagement screen.

**Findings**
- STYLE: Backup file should not live under `src`; remove to avoid accidental imports.

**Security & Reliability**
- N/A.

**Performance & Complexity**
- N/A.

**Readability & Maintainability**
- Delete or move to documentation.

**Quick Fixes**
- Remove file from `src`.

**Test Ideas**
- N/A.

